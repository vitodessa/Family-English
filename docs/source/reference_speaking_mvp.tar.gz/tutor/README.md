# English Tutor — голосовой репетитор на Claude API

MVP персонального репетитора английского для семьи. Ведёт голосовой диалог, отслеживает ошибки, повторяет слова по алгоритму интервального повторения (SM-2), адаптируется под уровень ученика.

## Стек
- **Backend**: Python 3.11 + FastAPI + SQLAlchemy + Anthropic SDK
- **БД**: PostgreSQL
- **Frontend**: одностраничное приложение (HTML/CSS/JS), Web Speech API для голоса
- **LLM**: Claude Sonnet 4.5 + prompt caching

## Что умеет

1. **Профили учеников** — для каждого члена семьи свой профиль, уровень, цели, интересы
2. **Голосовой диалог** — распознавание в браузере (Web Speech API), синтез речи там же. Бесплатно
3. **Анализ ошибок** — Claude после каждой реплики возвращает структурированный JSON: что было сказано, какие ошибки, какая категория, как правильно
4. **Словарный запас с SRS** — новые слова сохраняются, повторяются по алгоритму SM-2 (как Anki)
5. **Адаптация** — системный промпт обновляется перед каждой сессией: профиль + последние ошибки + слова на сегодня
6. **Дашборд прогресса** — статистика ошибок по категориям, выученные слова, время занятий

## Структура

```
tutor/
├── backend/
│   ├── app/
│   │   ├── main.py          # FastAPI endpoints
│   │   ├── models.py        # SQLAlchemy модели
│   │   ├── database.py      # подключение к Postgres
│   │   ├── schemas.py       # Pydantic схемы
│   │   ├── tutor.py         # логика общения с Claude
│   │   ├── srs.py           # алгоритм интервального повторения SM-2
│   │   └── prompts.py       # системные промпты
│   ├── requirements.txt
│   └── .env.example
└── frontend/
    ├── index.html
    ├── app.js
    └── styles.css
```

## Развёртывание на VPS

### 1. PostgreSQL
```bash
sudo apt install postgresql
sudo -u postgres psql
CREATE DATABASE tutor;
CREATE USER tutor WITH PASSWORD 'change_me';
GRANT ALL PRIVILEGES ON DATABASE tutor TO tutor;
\q
```

### 2. Backend
```bash
cd backend
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# отредактируй .env: ANTHROPIC_API_KEY, DATABASE_URL
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

При первом запуске таблицы создадутся автоматически.

### 3. Frontend
Можно открыть `frontend/index.html` локально или раздавать через nginx. В `app.js` поменяй `API_BASE` на адрес твоего VPS.

### 4. systemd unit (опционально)
Создай `/etc/systemd/system/tutor.service`:
```ini
[Unit]
Description=English Tutor API
After=network.target

[Service]
User=tutor
WorkingDirectory=/home/tutor/tutor/backend
Environment="PATH=/home/tutor/tutor/backend/venv/bin"
ExecStart=/home/tutor/tutor/backend/venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8000
Restart=always

[Install]
WantedBy=multi-user.target
```

## Стоимость

При семье 3–4 человека по 30 мин/день и prompt caching — **$15–25/мес** на Claude API. Голос через браузер — бесплатно.

## Что можно добавить дальше

- Премиум TTS через ElevenLabs (если синтез браузера не нравится)
- Telegram-бот как альтернативный интерфейс
- Экспорт ошибок и слов в Anki
- Произношение: запись голоса → отправка в Whisper → Claude оценивает фонетику
