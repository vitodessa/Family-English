// =========================================================
// Tutor frontend — Web Speech API + backend bridge
// =========================================================

const API_BASE = "http://localhost:8000"; // <-- замени на адрес VPS
document.getElementById("apiBaseDisplay").textContent = API_BASE;

// ---- state ----
let currentStudentId = null;
let currentSessionId = null;
let recognition = null;
let isRecording = false;
let currentReviewQueue = [];
let currentReviewIndex = 0;

// ---- tabs ----
document.querySelectorAll(".tab").forEach(t => {
  t.onclick = () => {
    document.querySelectorAll(".tab").forEach(x => x.classList.remove("active"));
    document.querySelectorAll(".view").forEach(x => x.classList.remove("active"));
    t.classList.add("active");
    document.getElementById("view-" + t.dataset.tab).classList.add("active");

    if (t.dataset.tab === "vocab") loadVocabView();
    if (t.dataset.tab === "stats") loadStats();
  };
});

// ---- API helper ----
async function api(path, opts = {}) {
  const res = await fetch(API_BASE + path, {
    headers: { "Content-Type": "application/json" },
    ...opts,
  });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`API ${res.status}: ${txt}`);
  }
  return res.json();
}

// ---- students ----
async function loadStudents() {
  const list = await api("/students");
  const sel = document.getElementById("studentSelect");
  sel.innerHTML = "";
  if (list.length === 0) {
    sel.innerHTML = '<option value="">— no students yet, go to Setup —</option>';
    return;
  }
  list.forEach(s => {
    const o = document.createElement("option");
    o.value = s.id;
    o.textContent = `${s.name} · ${s.level}`;
    sel.appendChild(o);
  });
  currentStudentId = parseInt(sel.value);
  sel.onchange = () => { currentStudentId = parseInt(sel.value); };
}

document.getElementById("createStudentBtn").onclick = async () => {
  const payload = {
    name: document.getElementById("newName").value.trim(),
    level: document.getElementById("newLevel").value,
    goal: document.getElementById("newGoal").value.trim(),
    interests: document.getElementById("newInterests").value.trim(),
    daily_minutes: parseInt(document.getElementById("newMinutes").value) || 20,
  };
  if (!payload.name) { alert("Введи имя"); return; }
  await api("/students", { method: "POST", body: JSON.stringify(payload) });
  document.getElementById("newName").value = "";
  document.getElementById("newInterests").value = "";
  await loadStudents();
  alert("Student created");
};

// ---- session ----
document.getElementById("startBtn").onclick = async () => {
  if (!currentStudentId) { alert("Выбери ученика"); return; }
  const topic = document.getElementById("topicInput").value.trim();
  const sess = await api("/sessions", {
    method: "POST",
    body: JSON.stringify({ student_id: currentStudentId, topic: topic || null }),
  });
  currentSessionId = sess.id;
  document.getElementById("micBtn").disabled = false;
  document.getElementById("endBtn").disabled = false;
  document.getElementById("startBtn").disabled = true;
  document.getElementById("conversation").innerHTML = "";

  // первая реплика от ассистента — отправляем пустой "starter"
  await sendUserText("(start)");
};

document.getElementById("endBtn").onclick = async () => {
  if (!currentSessionId) return;
  await api(`/sessions/${currentSessionId}/end`, { method: "POST" });
  currentSessionId = null;
  document.getElementById("micBtn").disabled = true;
  document.getElementById("endBtn").disabled = true;
  document.getElementById("startBtn").disabled = false;
};

// ---- conversation rendering ----
function addBubble(role, text) {
  const conv = document.getElementById("conversation");
  // убираем placeholder
  const ph = conv.querySelector(".placeholder");
  if (ph) ph.remove();
  const b = document.createElement("div");
  b.className = "bubble " + role;
  b.innerHTML = `<div class="who">${role === "user" ? "you" : "tutor"}</div>
                 <div class="text"></div>`;
  b.querySelector(".text").textContent = text;
  conv.appendChild(b);
  conv.scrollTop = conv.scrollHeight;
}

function renderMistakes(list) {
  const el = document.getElementById("mistakesList");
  if (!list || list.length === 0) {
    el.innerHTML = '<p class="muted">No mistakes — great!</p>';
    return;
  }
  el.innerHTML = list.map(m => `
    <div class="mistake-item">
      <span class="cat">${escapeHtml(m.category)}</span>
      <div><span class="orig">${escapeHtml(m.original)}</span></div>
      <div><span class="corr">${escapeHtml(m.correction)}</span></div>
      <div class="expl">${escapeHtml(m.explanation)}</div>
    </div>`).join("");
}

function renderNewVocab(list) {
  const el = document.getElementById("vocabList");
  if (!list || list.length === 0) {
    el.innerHTML = '<p class="muted">No new words this turn.</p>';
    return;
  }
  el.innerHTML = list.map(v => `
    <div class="vocab-item">
      <div class="word">${escapeHtml(v.word)}</div>
      <div class="trans">${escapeHtml(v.translation)}</div>
      <div class="ex">${escapeHtml(v.example)}</div>
    </div>`).join("");
}

function escapeHtml(s) {
  return (s || "").replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[c]));
}

// ---- send to backend & speak ----
async function sendUserText(text) {
  if (text !== "(start)") addBubble("user", text);
  setMicStatus("Thinking…");
  try {
    const r = await api("/chat", {
      method: "POST",
      body: JSON.stringify({ session_id: currentSessionId, user_text: text }),
    });
    addBubble("assistant", r.reply);
    renderMistakes(r.mistakes);
    renderNewVocab(r.new_vocab);
    speak(r.reply);
  } catch (e) {
    addBubble("assistant", "[error] " + e.message);
    setMicStatus("Error");
  }
}

// ---- speech synthesis ----
function speak(text) {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = "en-US";
  u.rate = 0.95;
  // выбираем приличный английский голос, если есть
  const voices = window.speechSynthesis.getVoices();
  const preferred = voices.find(v =>
    v.lang.startsWith("en") && /Google|Microsoft|Samantha|Karen|Daniel/i.test(v.name)
  ) || voices.find(v => v.lang.startsWith("en"));
  if (preferred) u.voice = preferred;
  u.onstart = () => setMicStatus("Speaking…");
  u.onend = () => setMicStatus("Idle — hold space to talk");
  window.speechSynthesis.speak(u);
}

// загрузим голоса (в Chrome нужен callback)
window.speechSynthesis?.addEventListener("voiceschanged", () => {});

// ---- speech recognition ----
function initRecognition() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) {
    setMicStatus("Браузер не поддерживает распознавание речи. Используй Chrome или Edge.");
    return;
  }
  recognition = new SR();
  recognition.lang = "en-US";
  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.onresult = (e) => {
    const text = e.results[0][0].transcript;
    sendUserText(text);
  };
  recognition.onerror = (e) => {
    setMicStatus("Mic error: " + e.error);
    stopRecording();
  };
  recognition.onend = () => stopRecording();
}

function setMicStatus(s) { document.getElementById("micStatus").textContent = s; }

function startRecording() {
  if (!recognition || isRecording || !currentSessionId) return;
  // прерываем синтез, если ассистент ещё говорит
  window.speechSynthesis?.cancel();
  isRecording = true;
  document.getElementById("micBtn").classList.add("recording");
  setMicStatus("Listening…");
  try { recognition.start(); } catch (e) { /* already running */ }
}

function stopRecording() {
  if (!isRecording) return;
  isRecording = false;
  document.getElementById("micBtn").classList.remove("recording");
  try { recognition.stop(); } catch (e) {}
}

// hold-to-talk на space + клик
document.addEventListener("keydown", (e) => {
  if (e.code === "Space" && !e.repeat && !["INPUT","TEXTAREA","SELECT"].includes(document.activeElement.tagName)) {
    e.preventDefault();
    startRecording();
  }
});
document.addEventListener("keyup", (e) => {
  if (e.code === "Space" && !["INPUT","TEXTAREA","SELECT"].includes(document.activeElement.tagName)) {
    e.preventDefault();
    stopRecording();
  }
});

const micBtn = document.getElementById("micBtn");
micBtn.addEventListener("mousedown", startRecording);
micBtn.addEventListener("mouseup", stopRecording);
micBtn.addEventListener("touchstart", (e) => { e.preventDefault(); startRecording(); });
micBtn.addEventListener("touchend", (e) => { e.preventDefault(); stopRecording(); });

// ---- vocab view ----
async function loadVocabView() {
  if (!currentStudentId) {
    document.getElementById("reviewArea").innerHTML = '<p class="muted">Pick a student in the Lesson tab first.</p>';
    document.getElementById("vocabTable").innerHTML = "";
    return;
  }
  currentReviewQueue = await api(`/students/${currentStudentId}/vocab/due`);
  currentReviewIndex = 0;
  renderReviewCard();

  const all = await api(`/students/${currentStudentId}/vocab`);
  const t = document.getElementById("vocabTable");
  if (all.length === 0) {
    t.innerHTML = '<div style="padding:20px" class="muted">Vocabulary is empty.</div>';
    return;
  }
  t.innerHTML = all.map(v => `
    <div class="vocab-row">
      <div class="vw">${escapeHtml(v.word)}</div>
      <div class="vt">${escapeHtml(v.translation)}</div>
      <div class="vd">due ${v.due_date}</div>
    </div>`).join("");
}

function renderReviewCard() {
  const area = document.getElementById("reviewArea");
  if (currentReviewQueue.length === 0) {
    area.innerHTML = '<p class="muted">Nothing due today. Come back tomorrow 🍃</p>';
    return;
  }
  if (currentReviewIndex >= currentReviewQueue.length) {
    area.innerHTML = '<p class="muted">All done for today. Nice work.</p>';
    return;
  }
  const v = currentReviewQueue[currentReviewIndex];
  area.innerHTML = `
    <div class="review-card">
      <div class="muted">Card ${currentReviewIndex + 1} of ${currentReviewQueue.length}</div>
      <div class="word">${escapeHtml(v.word)}</div>
      <div class="translation" id="rTrans" style="visibility:hidden">${escapeHtml(v.translation)}</div>
      <div class="example" id="rEx" style="visibility:hidden">${escapeHtml(v.example)}</div>
      <button class="btn ghost small" id="showBtn">Show translation</button>
      <div class="quality-row" id="qRow" style="display:none; margin-top:24px">
        <button class="q-btn again" data-q="0">Again</button>
        <button class="q-btn" data-q="3">Hard</button>
        <button class="q-btn good" data-q="4">Good</button>
        <button class="q-btn good" data-q="5">Easy</button>
      </div>
    </div>`;
  document.getElementById("showBtn").onclick = () => {
    document.getElementById("rTrans").style.visibility = "visible";
    document.getElementById("rEx").style.visibility = "visible";
    document.getElementById("showBtn").style.display = "none";
    document.getElementById("qRow").style.display = "flex";
  };
  document.querySelectorAll(".q-btn").forEach(b => {
    b.onclick = async () => {
      const q = parseInt(b.dataset.q);
      await api("/vocab/review", {
        method: "POST",
        body: JSON.stringify({ vocab_id: v.id, quality: q }),
      });
      currentReviewIndex++;
      renderReviewCard();
    };
  });
}

// ---- stats ----
async function loadStats() {
  if (!currentStudentId) {
    document.getElementById("statsArea").innerHTML = '<p class="muted">Pick a student in the Lesson tab first.</p>';
    return;
  }
  const s = await api(`/students/${currentStudentId}/stats`);
  const maxCat = Math.max(1, ...s.mistakes_by_category.map(c => c.count));
  document.getElementById("statsArea").innerHTML = `
    <div class="stat-grid">
      <div class="stat-card"><div class="num">${s.total_sessions}</div><div class="lbl">Sessions</div></div>
      <div class="stat-card"><div class="num">${s.minutes_last_7_days}</div><div class="lbl">Min last 7d</div></div>
      <div class="stat-card"><div class="num">${s.vocab_total}</div><div class="lbl">Words learned</div></div>
      <div class="stat-card"><div class="num">${s.vocab_due_today}</div><div class="lbl">Due today</div></div>
    </div>
    <h3 style="font-style:italic;font-weight:400;font-size:28px;margin:0 0 8px">Mistakes by category</h3>
    <p class="muted">Where the tutor focuses its corrections.</p>
    <div class="cat-bars">
      ${s.mistakes_by_category.map(c => `
        <div class="cat-row">
          <div class="cn">${escapeHtml(c.category)}</div>
          <div class="cbar"><span style="width:${(c.count / maxCat * 100).toFixed(0)}%"></span></div>
          <div class="cv">${c.count}</div>
        </div>`).join("") || '<p class="muted">No data yet.</p>'}
    </div>`;
}

// ---- init ----
initRecognition();
loadStudents();
