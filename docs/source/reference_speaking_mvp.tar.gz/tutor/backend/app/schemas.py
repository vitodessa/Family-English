"""Pydantic схемы для API."""
from datetime import datetime, date
from typing import Optional, List
from pydantic import BaseModel, ConfigDict


# --- Student ---
class StudentCreate(BaseModel):
    name: str
    level: str = "A2"
    goal: str = "разговорный английский"
    interests: str = ""
    daily_minutes: int = 20


class StudentOut(StudentCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: datetime


# --- Session ---
class SessionCreate(BaseModel):
    student_id: int
    topic: Optional[str] = None


class SessionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    student_id: int
    started_at: datetime
    ended_at: Optional[datetime]
    topic: str
    summary: str


# --- Chat ---
class ChatTurnIn(BaseModel):
    session_id: int
    user_text: str


class MistakeOut(BaseModel):
    original: str
    correction: str
    explanation: str
    category: str


class VocabOut(BaseModel):
    word: str
    translation: str
    example: str


class ChatTurnOut(BaseModel):
    """Что возвращаем фронту после реплики ученика."""
    reply: str                       # ответ репетитора (то, что озвучивать)
    mistakes: List[MistakeOut] = []  # ошибки в реплике ученика
    new_vocab: List[VocabOut] = []   # новые слова, добавленные в словарь


# --- Stats ---
class CategoryStat(BaseModel):
    category: str
    count: int


class StatsOut(BaseModel):
    total_sessions: int
    total_messages: int
    total_mistakes: int
    mistakes_by_category: List[CategoryStat]
    vocab_total: int
    vocab_due_today: int
    minutes_last_7_days: int


# --- Vocab review ---
class VocabReviewIn(BaseModel):
    vocab_id: int
    quality: int  # 0..5 по SM-2: <3 = забыл, >=3 = вспомнил


class VocabItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    word: str
    translation: str
    example: str
    due_date: date
    interval_days: int
