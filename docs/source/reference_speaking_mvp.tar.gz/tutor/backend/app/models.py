"""Схема БД для репетитора.

Идея:
- Student: профиль ученика (один на каждого члена семьи)
- Session: сеанс занятия (создаётся при начале разговора)
- Message: каждая реплика в сессии (user/assistant)
- Mistake: ошибка, найденная Claude в реплике ученика, с категорией
- VocabItem: слово в личном словаре с состоянием SRS (интервал, ease, due_date)
"""
from datetime import datetime, date
from sqlalchemy import (
    Column, Integer, String, Text, DateTime, Date, ForeignKey, Float, Boolean
)
from sqlalchemy.orm import relationship
from .database import Base


class Student(Base):
    __tablename__ = "students"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    # CEFR: A1 / A2 / B1 / B2 / C1 / C2
    level = Column(String(2), default="A2")
    goal = Column(String(200), default="разговорный английский")
    interests = Column(Text, default="")  # через запятую
    daily_minutes = Column(Integer, default=20)
    created_at = Column(DateTime, default=datetime.utcnow)

    sessions = relationship("Session", back_populates="student", cascade="all, delete-orphan")
    mistakes = relationship("Mistake", back_populates="student", cascade="all, delete-orphan")
    vocab = relationship("VocabItem", back_populates="student", cascade="all, delete-orphan")


class Session(Base):
    __tablename__ = "sessions"

    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    started_at = Column(DateTime, default=datetime.utcnow)
    ended_at = Column(DateTime, nullable=True)
    topic = Column(String(200), default="")
    summary = Column(Text, default="")  # короткое резюме сессии (генерируется в конце)

    student = relationship("Student", back_populates="sessions")
    messages = relationship("Message", back_populates="session",
                            cascade="all, delete-orphan", order_by="Message.id")


class Message(Base):
    __tablename__ = "messages"

    id = Column(Integer, primary_key=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=False)
    role = Column(String(20), nullable=False)  # 'user' | 'assistant'
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    session = relationship("Session", back_populates="messages")


class Mistake(Base):
    __tablename__ = "mistakes"

    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=True)
    original = Column(Text, nullable=False)        # что сказал ученик
    correction = Column(Text, nullable=False)      # исправленный вариант
    explanation = Column(Text, default="")         # почему ошибка
    category = Column(String(50), default="other") # grammar/vocab/articles/tense/...
    created_at = Column(DateTime, default=datetime.utcnow)

    student = relationship("Student", back_populates="mistakes")


class VocabItem(Base):
    """Элемент словаря с состоянием SuperMemo-2."""
    __tablename__ = "vocab"

    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    word = Column(String(100), nullable=False)
    translation = Column(String(200), default="")
    example = Column(Text, default="")             # пример предложения с этим словом

    # SM-2 поля
    repetition = Column(Integer, default=0)        # сколько раз подряд успешно повторили
    interval_days = Column(Integer, default=1)     # текущий интервал в днях
    ease = Column(Float, default=2.5)              # коэффициент сложности (от 1.3)
    due_date = Column(Date, default=date.today)    # когда показывать в следующий раз

    created_at = Column(DateTime, default=datetime.utcnow)

    student = relationship("Student", back_populates="vocab")
