"""Слой взаимодействия с Claude API.

Главная функция — process_student_turn(): принимает реплику ученика,
собирает контекст, зовёт Claude, парсит структурированный ответ,
сохраняет ошибки и новые слова в БД.
"""
import json
import os
from datetime import date
from typing import List

from anthropic import Anthropic
from sqlalchemy.orm import Session as DBSession

from .models import Student, Session, Message, Mistake, VocabItem
from .prompts import STATIC_TUTOR_INSTRUCTIONS, build_dynamic_context


client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-5")


def _get_recent_mistakes(db: DBSession, student_id: int, limit: int = 15) -> List[Mistake]:
    return (db.query(Mistake)
              .filter(Mistake.student_id == student_id)
              .order_by(Mistake.created_at.desc())
              .limit(limit)
              .all())


def _get_due_vocab(db: DBSession, student_id: int, limit: int = 10) -> List[VocabItem]:
    return (db.query(VocabItem)
              .filter(VocabItem.student_id == student_id,
                      VocabItem.due_date <= date.today())
              .order_by(VocabItem.due_date)
              .limit(limit)
              .all())


def _build_message_history(db: DBSession, session_id: int) -> List[dict]:
    """Восстанавливает историю диалога из БД в формате Anthropic API."""
    msgs = (db.query(Message)
              .filter(Message.session_id == session_id)
              .order_by(Message.id)
              .all())
    return [{"role": m.role, "content": m.content} for m in msgs]


def _parse_claude_response(raw: str) -> dict:
    """Парсит JSON-ответ Claude. На всякий случай чистим от markdown-обёрток."""
    text = raw.strip()
    if text.startswith("```"):
        # снимаем ```json ... ```
        text = text.split("```", 2)[1]
        if text.startswith("json"):
            text = text[4:]
        text = text.strip().rstrip("`").strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # fallback: возвращаем как есть в reply, без структуры
        return {"reply": raw, "mistakes": [], "new_vocab": []}


def process_student_turn(db: DBSession, session_id: int, user_text: str) -> dict:
    """Главная функция: обрабатывает реплику ученика, возвращает ответ репетитора.

    Шаги:
    1. Загружаем сессию и ученика
    2. Сохраняем реплику ученика в БД
    3. Собираем контекст (профиль, недавние ошибки, слова на сегодня)
    4. Вызываем Claude с кэшированной статической инструкцией
    5. Парсим JSON-ответ
    6. Сохраняем ошибки и новые слова, сохраняем ответ ассистента
    7. Возвращаем dict для фронта
    """
    session = db.query(Session).filter(Session.id == session_id).first()
    if not session:
        raise ValueError(f"Session {session_id} not found")

    student = db.query(Student).filter(Student.id == session.student_id).first()
    if not student:
        raise ValueError(f"Student {session.student_id} not found")

    # 1. сохраняем реплику ученика
    user_msg = Message(session_id=session_id, role="user", content=user_text)
    db.add(user_msg)
    db.flush()

    # 2. собираем контекст
    recent_mistakes = _get_recent_mistakes(db, student.id)
    due_vocab = _get_due_vocab(db, student.id)
    dynamic_ctx = build_dynamic_context(
        student=student,
        recent_mistakes=recent_mistakes,
        due_vocab=due_vocab,
        topic=session.topic or "",
    )

    # 3. строим запрос с кэшированной системной инструкцией
    history = _build_message_history(db, session_id)

    response = client.messages.create(
        model=MODEL,
        max_tokens=800,
        system=[
            {
                "type": "text",
                "text": STATIC_TUTOR_INSTRUCTIONS,
                "cache_control": {"type": "ephemeral"},  # кэшируем большой статичный кусок
            },
            {
                "type": "text",
                "text": dynamic_ctx,
            },
        ],
        messages=history,
    )

    raw_reply = "".join(block.text for block in response.content if block.type == "text")
    parsed = _parse_claude_response(raw_reply)

    reply_text = parsed.get("reply", "")
    mistakes = parsed.get("mistakes", []) or []
    new_vocab = parsed.get("new_vocab", []) or []

    # 4. сохраняем ответ ассистента (то, что озвучивается)
    assistant_msg = Message(session_id=session_id, role="assistant", content=reply_text)
    db.add(assistant_msg)

    # 5. сохраняем ошибки
    for m in mistakes:
        db.add(Mistake(
            student_id=student.id,
            session_id=session_id,
            original=m.get("original", ""),
            correction=m.get("correction", ""),
            explanation=m.get("explanation", ""),
            category=m.get("category", "other"),
        ))

    # 6. сохраняем новые слова (с дедупликацией)
    for v in new_vocab:
        word = (v.get("word") or "").strip().lower()
        if not word:
            continue
        existing = (db.query(VocabItem)
                      .filter(VocabItem.student_id == student.id,
                              VocabItem.word == word)
                      .first())
        if existing:
            continue
        db.add(VocabItem(
            student_id=student.id,
            word=word,
            translation=v.get("translation", ""),
            example=v.get("example", ""),
        ))

    db.commit()

    return {
        "reply": reply_text,
        "mistakes": mistakes,
        "new_vocab": new_vocab,
    }
