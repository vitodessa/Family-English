"""Реализация SuperMemo-2 (SM-2) для словарных карточек.

Качество ответа от ученика по шкале 0..5:
    5 — вспомнил мгновенно, без усилий
    4 — вспомнил с лёгкой задержкой
    3 — вспомнил с трудом
    2 — не вспомнил, но узнал правильный ответ
    1 — не вспомнил, ответ выглядел знакомым
    0 — полный провал

Если quality < 3 — карточка сбрасывается на интервал 1 день.
Иначе интервал растёт по формуле, ease меняется.
"""
from datetime import date, timedelta
from .models import VocabItem


def apply_sm2(item: VocabItem, quality: int) -> VocabItem:
    """Обновляет SRS-поля карточки на основе оценки качества."""
    quality = max(0, min(5, quality))

    if quality < 3:
        # забыл — начинаем заново
        item.repetition = 0
        item.interval_days = 1
    else:
        if item.repetition == 0:
            item.interval_days = 1
        elif item.repetition == 1:
            item.interval_days = 6
        else:
            item.interval_days = round(item.interval_days * item.ease)
        item.repetition += 1

    # обновляем ease
    new_ease = item.ease + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02))
    item.ease = max(1.3, new_ease)

    item.due_date = date.today() + timedelta(days=item.interval_days)
    return item
