"""FastAPI приложение: REST API для репетитора."""
import os
from datetime import datetime, date, timedelta
from typing import List

from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import func
from sqlalchemy.orm import Session as DBSession
from dotenv import load_dotenv

from . import models, schemas
from .database import engine, get_db
from .tutor import process_student_turn
from .srs import apply_sm2

load_dotenv()

# создаём таблицы при первом запуске
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="English Tutor API", version="0.1.0")

origins = os.getenv("ALLOWED_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------- Students ----------
@app.post("/students", response_model=schemas.StudentOut)
def create_student(payload: schemas.StudentCreate, db: DBSession = Depends(get_db)):
    student = models.Student(**payload.model_dump())
    db.add(student)
    db.commit()
    db.refresh(student)
    return student


@app.get("/students", response_model=List[schemas.StudentOut])
def list_students(db: DBSession = Depends(get_db)):
    return db.query(models.Student).order_by(models.Student.id).all()


@app.get("/students/{student_id}", response_model=schemas.StudentOut)
def get_student(student_id: int, db: DBSession = Depends(get_db)):
    s = db.query(models.Student).filter(models.Student.id == student_id).first()
    if not s:
        raise HTTPException(404, "Student not found")
    return s


@app.put("/students/{student_id}", response_model=schemas.StudentOut)
def update_student(student_id: int, payload: schemas.StudentCreate,
                   db: DBSession = Depends(get_db)):
    s = db.query(models.Student).filter(models.Student.id == student_id).first()
    if not s:
        raise HTTPException(404, "Student not found")
    for k, v in payload.model_dump().items():
        setattr(s, k, v)
    db.commit()
    db.refresh(s)
    return s


# ---------- Sessions ----------
@app.post("/sessions", response_model=schemas.SessionOut)
def start_session(payload: schemas.SessionCreate, db: DBSession = Depends(get_db)):
    student = db.query(models.Student).filter(models.Student.id == payload.student_id).first()
    if not student:
        raise HTTPException(404, "Student not found")
    sess = models.Session(student_id=payload.student_id, topic=payload.topic or "")
    db.add(sess)
    db.commit()
    db.refresh(sess)
    return sess


@app.post("/sessions/{session_id}/end", response_model=schemas.SessionOut)
def end_session(session_id: int, db: DBSession = Depends(get_db)):
    sess = db.query(models.Session).filter(models.Session.id == session_id).first()
    if not sess:
        raise HTTPException(404, "Session not found")
    sess.ended_at = datetime.utcnow()
    db.commit()
    db.refresh(sess)
    return sess


# ---------- Chat ----------
@app.post("/chat", response_model=schemas.ChatTurnOut)
def chat_turn(payload: schemas.ChatTurnIn, db: DBSession = Depends(get_db)):
    try:
        result = process_student_turn(db, payload.session_id, payload.user_text)
    except ValueError as e:
        raise HTTPException(404, str(e))
    return result


# ---------- Vocab ----------
@app.get("/students/{student_id}/vocab/due", response_model=List[schemas.VocabItemOut])
def vocab_due(student_id: int, db: DBSession = Depends(get_db)):
    return (db.query(models.VocabItem)
              .filter(models.VocabItem.student_id == student_id,
                      models.VocabItem.due_date <= date.today())
              .order_by(models.VocabItem.due_date)
              .all())


@app.get("/students/{student_id}/vocab", response_model=List[schemas.VocabItemOut])
def vocab_all(student_id: int, db: DBSession = Depends(get_db)):
    return (db.query(models.VocabItem)
              .filter(models.VocabItem.student_id == student_id)
              .order_by(models.VocabItem.due_date)
              .all())


@app.post("/vocab/review")
def vocab_review(payload: schemas.VocabReviewIn, db: DBSession = Depends(get_db)):
    item = db.query(models.VocabItem).filter(models.VocabItem.id == payload.vocab_id).first()
    if not item:
        raise HTTPException(404, "Vocab item not found")
    apply_sm2(item, payload.quality)
    db.commit()
    db.refresh(item)
    return {
        "id": item.id,
        "interval_days": item.interval_days,
        "due_date": item.due_date.isoformat(),
        "ease": round(item.ease, 2),
    }


# ---------- Stats ----------
@app.get("/students/{student_id}/stats", response_model=schemas.StatsOut)
def stats(student_id: int, db: DBSession = Depends(get_db)):
    s = db.query(models.Student).filter(models.Student.id == student_id).first()
    if not s:
        raise HTTPException(404, "Student not found")

    total_sessions = (db.query(func.count(models.Session.id))
                        .filter(models.Session.student_id == student_id).scalar() or 0)
    total_messages = (db.query(func.count(models.Message.id))
                        .join(models.Session)
                        .filter(models.Session.student_id == student_id).scalar() or 0)
    total_mistakes = (db.query(func.count(models.Mistake.id))
                        .filter(models.Mistake.student_id == student_id).scalar() or 0)

    by_cat_rows = (db.query(models.Mistake.category, func.count(models.Mistake.id))
                     .filter(models.Mistake.student_id == student_id)
                     .group_by(models.Mistake.category)
                     .all())
    by_cat = [schemas.CategoryStat(category=c, count=n) for c, n in by_cat_rows]

    vocab_total = (db.query(func.count(models.VocabItem.id))
                     .filter(models.VocabItem.student_id == student_id).scalar() or 0)
    vocab_due_today = (db.query(func.count(models.VocabItem.id))
                         .filter(models.VocabItem.student_id == student_id,
                                 models.VocabItem.due_date <= date.today())
                         .scalar() or 0)

    # минуты за последние 7 дней — оцениваем по числу пар реплик (~30 сек на пару)
    week_ago = datetime.utcnow() - timedelta(days=7)
    msgs_week = (db.query(func.count(models.Message.id))
                   .join(models.Session)
                   .filter(models.Session.student_id == student_id,
                           models.Message.created_at >= week_ago)
                   .scalar() or 0)
    minutes_last_7_days = int((msgs_week / 2) * 0.5)  # 30 сек на обмен — грубая оценка

    return schemas.StatsOut(
        total_sessions=total_sessions,
        total_messages=total_messages,
        total_mistakes=total_mistakes,
        mistakes_by_category=by_cat,
        vocab_total=vocab_total,
        vocab_due_today=vocab_due_today,
        minutes_last_7_days=minutes_last_7_days,
    )


@app.get("/")
def root():
    return {"status": "ok", "service": "English Tutor API"}
