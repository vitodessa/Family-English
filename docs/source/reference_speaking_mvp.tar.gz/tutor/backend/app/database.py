"""Подключение к Postgres и базовый класс моделей."""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://tutor:tutor@localhost:5432/tutor")

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """Зависимость FastAPI: открывает сессию на запрос и закрывает после."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
